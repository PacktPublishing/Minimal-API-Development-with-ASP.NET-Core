﻿namespace StudentEnrollment.Api.DTOs
{
    public class ErrorResponseDto
    {
        public string Code { get; set; }
        public string Description { get; set; }
    }
}
